/**
* jAlert v.1.0.0
* Copyright (c) 2008 Julian Castaneda
* http://www.smooka.com/blog/
* Requires: jQuery 1.2+
*/

(function($) {
    $.fn.jAlert2 = function (msg, type, uid, alert_box_width, yoffset)
    {
        var tmpobj = this;
        var move_flag = false;
				
		if (uid == undefined)
		{	//generate an unique ID
			var d = new Date();
			var uid = d.getMonth()+""+d.getDate()+""+d.getHours()+""+d.getMinutes()+""+d.getSeconds();
		}

		if ($('#jalert_box_cont_'+uid).css('display') == 'block') {
            $("#jalert_box_cont_"+uid).fadeOut(100);
			$("#jalert_box_cont_"+uid).empty();
			$("#jalert_box_cont_"+uid).remove();
			$(window).unbind("resize");
			//return;
		}
		
        if (!type) {
            // set type to a default warning
            type = 'warning';
        }

        if (!alert_box_width) {
            //set default width of alert box
            alert_box_width = 300;
        }

        if (!yoffset) {
            //set default y offset of alert box
            yoffset = 0;
        }

        //create a prepend the alert box to the container
        $('<div class="msg-box-cont msg-'+type+'" id="jalert_box_cont_'+uid+'">' +
            '<table width="100%" border="0" cellpadding="0" cellspacing="0">' +
            '<tr><td><div class="msg-text"><label>'+msg+'</label></div></td><td width="35" valign="top">' +
            '<div class="msg-btn close-'+type+'"></div></td></tr></table></div>').appendTo('body');

        $("#jalert_box_cont_"+uid).width(alert_box_width);

		//alignCenter();
		
        //get the y (top) position of the container
		var top = this.y() + yoffset;

        $("#jalert_box_cont_"+uid).css("top",top+"px");

        $("#jalert_box_cont_"+uid).css("left",(tmpobj.x()+50)+"px");
		
		$("#jalert_box_cont_"+uid).fadeIn(500);

        $("#jalert_box_cont_"+uid).mousedown(function() {
            move_flag = true;
        });

        $("#jalert_box_cont_"+uid).mouseup(function() {
            move_flag = false;
        });

        $(document).mousemove(function(e) {
            var handle = document.getElementById("jalert_box_cont_"+uid);
            if (move_flag == true) {
                divMove(handle,e);
            }
        });

        function divMove(handle,e){
            handle.style.top = (e.clientY - handle.clientHeight/2) + $(document).scrollTop() + 'px';
            handle.style.left = (e.clientX - handle.clientWidth/2) + $(document).scrollLeft() + 'px';
        }

        // remove box
		$('.msg-btn').click(function() {
			$("#jalert_box_cont_"+uid).fadeOut(100);
			$("#jalert_box_cont_"+uid).empty();
			$("#jalert_box_cont_"+uid).remove();
			$(window).unbind("resize");
		});

        //always center
        //$(window).resize(function() {alignCenter();});
				
		function alignCenter() {
			var alert_box_width = $("#jalert_box_cont_"+uid).width();
            //get the width of the container
            var container_width = tmpobj.innerWidth();
            // get the x position of the container
            var container_left = tmpobj.x();
            //get the center position of the alert box within the container
            var actual_left = ((container_width-alert_box_width)/2)+container_left;
            //get the y (top) position of the container
            $("#jalert_box_cont_"+uid).css("left",actual_left+"px");
		}

    };

    //vertical positioning
    $.fn.y = function(n) {
        var result = null;
        this.each(function() {
            var o = this;
            if (n === undefined) {
                var y = 0;
                if (o.offsetParent) {
                    while (o.offsetParent) {
                        y += o.offsetTop;
                        o = o.offsetParent;
                    }
                }
                if (result === null) {
                    result = y;
                } else {
                    result = Math.min(result, y);
                }
            } else {
                o.style.top = n + 'px';
            }
        });
        return result;
    };
    
    //horizontal positioning
    $.fn.x = function(n) {
        var result = null;
        this.each(function() {
            var o = this;
            if (n === undefined) {
                var x = 0;
                if (o.offsetParent) {
                    while (o.offsetParent) {
                        x += o.offsetLeft;
                        o = o.offsetParent;
                    }
                }
                if (result === null) {
                    result = x;
                } else {
                    result = Math.min(result, x);
                }
            } else {
                o.style.left = n + 'px';
            }
        });
        return result;
    };
})(jQuery);