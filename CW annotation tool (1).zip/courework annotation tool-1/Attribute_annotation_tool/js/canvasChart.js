﻿var CanvasChart = function () {
    var margin = { top: 20, left: 15, right: 20, bottom: 15 };
    var chartHeight, chartWidth, yMax, yRange, xMax, xRange, data;
    var maxYValue = 5;
    var ratio = 0;
    var renderType = { lines: 'lines', points: 'points' };

    // first draw the cache image, and make a copy of drawing from cache
    var render = function(canvas, cache_canvas, dataObj) {
        data = dataObj;
        //getMaxDataYValue();
        chartHeight = canvas.getAttribute('height');
        chartWidth = canvas.getAttribute('width');
        xMax = chartWidth - margin.right;
        yMax = chartHeight - margin.bottom;
        xRange = chartWidth - (margin.left + margin.right);
        yRange = chartHeight - (margin.top + margin.bottom);
        ratio = yRange / maxYValue;
        // firstly draw the cache
        var cache_ctx = cache_canvas.getContext("2d");
        cache_ctx.clearRect(0,0,chartWidth,chartHeight);
        renderChart(cache_ctx);
        // then draw on screen
        var ctx = canvas.getContext("2d");
        ctx.clearRect(0,0,chartWidth,chartHeight);
        ctx.drawImage(cache_canvas,0,0);
    };

    // use the cache drawing, combine play head on final drawing
    var renderPlayHead = function(canvas, cache_canvas, cIdx) {
        chartHeight = canvas.getAttribute('height');
        chartWidth = canvas.getAttribute('width');
        yMax = chartHeight - margin.bottom;
        xRange = chartWidth - (margin.left + margin.right);
        var ctx = canvas.getContext("2d");
        var xInc = getXInc();
        var ptX = (cIdx * xInc) + margin.left;
        // start drawing
        ctx.clearRect(0,0,chartWidth,chartHeight);
        ctx.drawImage(cache_canvas,0,0);
        drawLine(ctx, ptX, margin.top, ptX, yMax, 'blue');
    };

    var renderChart = function (ctx) {
        renderText(ctx);
        renderLinesAndLabels(ctx);

        //render data based upon type of renderType(s) that client supplies
        if (data.renderTypes == undefined || data.renderTypes == null) data.renderTypes = [renderType.lines];
        for (var i = 0; i < data.renderTypes.length; i++) {
            renderData(ctx,data.renderTypes[i]);
        }
    };

    var getMaxDataYValue = function () {
        for (var i = 0; i < data.dataPoints.length; i++) {
            if (data.dataPoints[i].y > maxYValue) maxYValue = data.dataPoints[i].y;
        }
    };

    var renderText = function(ctx) {
        var labelFont = (data.labelFont != null) ? data.labelFont : '20pt Arial';
        ctx.font = labelFont;
        ctx.textAlign = "center";

        //Title
        var txtSize = ctx.measureText(data.title);
        ctx.fillText(data.title, (chartWidth/15), margin.top-3);
    };

    var renderLinesAndLabels = function (ctx) {
        //Vertical guide lines
        var yInc = yRange / maxYValue;
        var yPos = 0;
        for (var i = 0; i < maxYValue; i++) {
            yPos += (i == 0) ? margin.top : yInc;
            //Draw horizontal lines
            drawLine(ctx, margin.left, yPos, xMax, yPos, 'lightgray');
        }

        //y axis labels
        ctx.font = (data.dataPointFont != null) ? data.dataPointFont : '10pt Calibri';
        var txtSize = ctx.measureText(0);
        ctx.fillText(0, margin.left - ((txtSize.width >= 10) ? txtSize.width : 6) - 5, yMax+4);
        ctx.fillText(5, margin.left - ((txtSize.width >= 10) ? txtSize.width : 6) - 5, margin.top+4);

        /*
        var yInc = yMax / data.dataPoints.length;
        var yPos = 0;
        var yLabelInc = (maxYValue * ratio) / data.dataPoints.length;
        var xInc = getXInc();
        var xPos = margin.left;
        for (var i = 0; i < data.dataPoints.length; i++) {
            yPos += (i == 0) ? margin.top : yInc;
            //Draw horizontal lines
            drawLine(margin.left, yPos, xMax, yPos, '#E8E8E8');


            //y axis labels
            ctx.font = (data.dataPointFont != null) ? data.dataPointFont : '10pt Calibri';
            var txt = Math.round(maxYValue - ((i == 0) ? 0 : yPos / ratio));
            var txtSize = ctx.measureText(txt);
            ctx.fillText(txt, margin.left - ((txtSize.width >= 14) ? txtSize.width : 10) - 7, yPos + 4);

            //x axis labels
            txt = data.dataPoints[i].x;
            txtSize = ctx.measureText(txt);
            ctx.fillText(txt, xPos, yMax + (margin.bottom / 3));
            xPos += xInc;

        }
        */

        //Vertical line
        drawLine(ctx, margin.left, margin.top, margin.left, yMax, 'black');

        //Horizontal Line
        drawLine(ctx, margin.left, yMax, xMax, yMax, 'black');
    };

    var renderData = function(ctx,type) {
        var xInc = getXInc();
        var prevX = 0, 
            prevY = 0;

        for (var i = 0; i < data.dataPoints.length; i++) {
            var pt = data.dataPoints[i];
            var ptY = margin.top + (maxYValue - pt.y) * ratio;
            if (ptY < margin.top) ptY = margin.top;
            var ptX = (i * xInc) + margin.left;

            if (i > 0 && type == renderType.lines) {
                //Draw connecting lines
                drawLine(ctx, ptX, ptY, prevX, prevY, 'red', 2);
            }

            if (type == renderType.points) {
                var radgrad = ctx.createRadialGradient(ptX, ptY, 8, ptX - 5, ptY - 5, 0);
                radgrad.addColorStop(0, 'Green');
                radgrad.addColorStop(0.9, 'White');
                ctx.beginPath();
                ctx.fillStyle = radgrad;
                //Render circle
                ctx.arc(ptX, ptY, 3, 0, 2 * Math.PI, false)
                ctx.fill();
                ctx.lineWidth = 1;
                ctx.strokeStyle = '#000';
                ctx.stroke();
                ctx.closePath();
            }

            prevX = ptX;
            prevY = ptY;
        }
    };

    var getXInc = function() {
        //return Math.round(xRange / (data.dataPoints.length-1)) - 1;
        return xRange / (data.dataPoints.length-1);
    };

    var drawLine = function(ctx, startX, startY, endX, endY, strokeStyle, lineWidth) {
        if (strokeStyle != null) ctx.strokeStyle = strokeStyle;
        if (lineWidth != null) ctx.lineWidth = lineWidth;
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.lineTo(endX, endY);
        ctx.stroke();
        ctx.closePath();
    };

    return {
        renderType: renderType,
        render: render,
        renderPlayHead: renderPlayHead,
    };
} ();
