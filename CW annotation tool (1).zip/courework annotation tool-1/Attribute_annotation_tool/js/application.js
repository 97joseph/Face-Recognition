//
const MIME_TYPE = 'text/plain';

const AU_ORDER = ['1','2','4','5','6','7','43','45','46',
                  '9','10','11','12','13','14','15','16',
                  '17','18','20','22','23','24','25','26','27','28'];

const AU_NAME = [ "Wrinkles", "Freakles",  "Glasses",  "Hair Color",
                 "Hair Top",      "Not Human",        "Duplicate",  "Error/Cannot Tell"];

const AU_EXAMPLE = ["au_01.png", "au_02.png", "au_04.png", "au_05.png", "au_06.png", "au_07.png",
                    "au_43.png", "au_45.gif"];



function pad(val) {
    if (val < 10) {
        val = "0" + val;
    }
    return val;
}

function formatTimer(position, frame_rate) {
   var ft_hours = Math.floor((position / (60 * 60)) % 24);
   var ft_minutes = Math.floor((position / 60 ) % 60);
   var ft_seconds = Math.floor(position % 60);
   var ft_frames = Math.floor((position - Math.floor(position)) * frame_rate);

   var hours_str = pad(ft_hours.toString());
   var minutes_str = pad(ft_minutes.toString());
   var seconds_str = pad(ft_seconds.toString());
   var frames_str = pad(ft_frames.toString());

   return hours_str + ':' + minutes_str + ':' + seconds_str + ':' + frames_str;
}

var rp_timer;

var SegmentVideo = {
    position_to_time : function(position_event) {
        var pos;
        var clickx = position_event.clientX - this.$video.offset().left;
        if (clickx >= (this.playbar_width)) {
          pos = this.video_element.duration;
        } else if (clickx <= 0) {
          pos = Math.floor(0);
        } else {
          pos = this.video_element.duration * (clickx / this.playbar_width);
        }
        this.video_element.currentTime = pos;
    },
    playpause : function() {
        // reset replay option
        this.reset_replay();
        if (this.playing) {
          this.stopMovie();
          this.playing = false;
        } else {
          this.playMovie();
          this.playing = true;
        }
    },
    reset_replay : function() {
        this.rp_interest = false;
        this.rp_start = -1;
        this.rp_end = -1;
    },
    replay_interest : function() {
        this.rp_interest = true;
        cframe = this.get_current_frame();
        var max = cframe, min = cframe;

        // middle to left
        for (var i = cframe; i >= 0; --i) {
            min = i;
            if (this.frame_interest[i] == 0) {
                min = i+1;
                break;
            }
        }
        // middle to right
        for (var i = cframe; i < this.get_total_frame()+1; ++i) {
            max = i;
            if (this.frame_interest[i] == 0) {
                max = i-1;
                break;
            }
        }
        this.rp_start = min;
        this.rp_end = max;

        // start to play, if at the end, then start from beginning
        if (cframe == this.rp_end) {
            this.set_current_frame(this.rp_start);
        }
        this.video_element.play();
        this.playing = true;
    },
    playHeadDrag : function() {
        this.playhead.mouse_down = true;
        if (this.playing) {
            this.startAgain = true;
            this.stopMovie();
        }
    },
    playMovie : function() {
        this.video_element.play();
        //$('#pp').removeClass('play').addClass('pause').text('Pause');
        document.getElementById('pp').setAttribute('src','icon/pause.png');
    },
    stopMovie : function() {
        this.video_element.pause();
        //$('#pp').removeClass('pause').addClass('play').text('Play');
        document.getElementById('pp').setAttribute('src','icon/play.png');
    },
    jump_frames : function(count) {
        this.video_element.currentTime = this.video_element.currentTime + (count / this.frame_rate);
    },
    loading : function() {
        if (this.video_element.buffered.length > 0) {
            if (this.video_element.buffered.end(0) >= this.video_element.duration) {
                $('#track_loaded').css('width', '100%');
                $('#track_annotated').css('width', '100%');
                $('#track_selection').css('width', '100%');
                $('#int_segment').css('width', '100%');
            } else {
                var pl = (this.video_element.buffered.end(0) / this.video_element.duration) * 100;
                $('#track_loaded').css('width', pl + '%');
                $('#track_annotated').css('width', pl + '%');
                $('#track_selection').css('width', pl + '%');
                $('#int_segment').css('width', pl + '%');
            }
        }
    },
    display_timecode : function() {
        // update frame number
        document.getElementById('goto_frame').value = this.get_current_frame();

        if (this.zoom_mode == true) {
            var bar = document.getElementById('zoom_frame');
            var cframe = this.get_current_frame();
            if (cframe >= bar.min && cframe <= bar.max) {
                document.getElementById('zoom_goto_frame').value = cframe;
                document.getElementById('zoom_frame').value = cframe;
                $('#int_start').text(bar.min);
                $('#int_end').text(bar.max);
            } else if (this.frame_interest[cframe] >= 1) {
                this.set_zoom_info(cframe);
                document.getElementById('zoom_goto_frame').value = cframe;
                document.getElementById('zoom_frame').value = cframe;
                $('#int_start').text(bar.min);
                $('#int_end').text(bar.max);
            }
        }
        // if change to other positions
        cframe = this.get_current_frame();
        if (cframe < this.pick_left || cframe > this.pick_right) {
            this.set_current_pick(cframe);
        }

        // clean submission message
        var output = document.getElementById('submit_au_success');
        this.clean_output(output);

        // display AB frame
        if (this.flag_A == false) {
            document.getElementById('start_A').setAttribute('border','0');
        }
        if (this.flag_B == false) {
            document.getElementById('end_B').setAttribute('border','0');
        }

        if (this.flag_A == false && this.flag_B == true) {
            this.frame_A = this.get_current_frame();
        } else if (this.flag_A == true && this.flag_B == false) {
            this.frame_B = this.get_current_frame();
        } else if (this.flag_A == false && this.flag_B == false) {
            this.frame_A = -1;
            this.frame_B = -1;
        }

        $('#out_frame_A').text(this.frame_A);
        $('#out_frame_B').text(this.frame_B);

        $('#total_frame').text(this.get_total_frame());
        //var total_width = Math.round((this.video_element.currentTime / this.video_element.duration) * (this.playbar_width));
        //$('#play_head').css('left', total_width - (this.playhead.width / 2.0) + 'px');
        var total_width = Math.round((this.video_element.currentTime / this.video_element.duration) * (this.playbar_width-this.playhead.width));
        $('#play_head').css('left', total_width + 'px');

        // update play head in aus_canvas
        this.update_canvas_playhead();
    },
    // draw annotated bar
    draw_track_annotated : function() {
        // draw
        var canvas = document.getElementById("track_annotated");
        var ctx = canvas.getContext("2d");
        var factor = canvas.width/this.playbar_width;
        var step_width = factor*(this.playbar_width-this.playhead.width)/(this.get_total_frame()+1);

        var n = this.get_total_frame();
        // firstly clean
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        ctx.fillStyle = 'red';
        for (var i = 0; i < n+1; ++i) {
            if (this.au[i] != null) {
                //ctx.fillRect(i*step_width, 0, Math.ceil(step_width), canvas.height);
                for (var k = 0; k < AU_ORDER.length; ++k) {
                    if (this.au[i][2*k] === true) {
                        ctx.fillRect(i*step_width, 0, Math.ceil(step_width), canvas.height);
                        break;
                    }
                }
            }
        }

        ctx.fillStyle = 'white';
        ctx.fillRect(factor*(this.playbar_width-this.playhead.width), 0, factor*this.playhead.width, canvas.height);
    },
    // draw selected annotation in bar
    draw_track_selection : function() {
        // draw
        var canvas = document.getElementById("track_selection");
        var ctx = canvas.getContext("2d");
        var factor = canvas.width/this.playbar_width;
        var step_width = factor*(this.playbar_width-this.playhead.width)/(this.get_total_frame()+1);

        var n = this.get_total_frame();
        // firstly clean
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        // if none of them should be displayed
        if (this.display_bar != -1) {
            for (var i = 0; i < AU_ORDER.length; ++i) {
                if (AU_ORDER[i] === this.display_bar) {  au_idx = i;  break;}
            }

            ctx.fillStyle = 'blue';
            for (var i = 0; i < n+1; ++i) {
                if (this.au[i] != null && this.au[i][2*au_idx] == true) {
                    ctx.fillRect(i*step_width, 0, Math.ceil(step_width), canvas.height);
                }
            }

            ctx.fillStyle = 'white';
            ctx.fillRect(factor*(this.playbar_width-this.playhead.width), 0, factor*this.playhead.width, canvas.height);
        }
    },
    // draw interest segment
    draw_track_interested : function() {
        // draw
        var canvas = document.getElementById("int_segment");
        var ctx = canvas.getContext("2d");
        var factor = canvas.width/this.playbar_width;
        var step_width = factor*(this.playbar_width-this.playhead.width)/(this.get_total_frame()+1);

        var n = this.get_total_frame();
        // firstly clean
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        for (var i = 0; i < n+1; ++i) {
            if (this.frame_interest[i] == 1) {  ctx.fillStyle = 'black';}
            else if (this.frame_interest[i] == 2) {  ctx.fillStyle = 'red';}

            if (this.frame_interest[i] > 0) {
                ctx.fillRect(i*step_width, 0, Math.ceil(step_width), canvas.height);
            }
        }
    },
    // update play head in aus_canvas
    update_canvas_playhead : function() {
        // update play head in aus_canvas
        var output = document.getElementById('aus_canvas');
        var children = output.childNodes;
        // get the cache
        var cache_output = document.getElementById('cache_aus_canvas');
        var cache_children = cache_output.childNodes;

        // redraw canvas play head
        for (var i = 0; i < children.length; ++i) {
            CanvasChart.renderPlayHead(children[i],cache_children[i],this.get_current_frame());
        }
    },
    // update aus canvas
    update_aus_canvas : function() {
        // update play head in aus_canvas
        var output = document.getElementById('aus_canvas');

        var children = output.childNodes;
        // get the cache
        var cache_output = document.getElementById('cache_aus_canvas');
        var cache_children = cache_output.childNodes;

        // redraw canvas
        for (var i = 0; i < children.length; ++i) {
            var idx = children[i].id.split("au_canv_");
            var dataDef = this.set_aus_display_data(parseInt(idx[1]));
            CanvasChart.render(children[i],cache_children[i],dataDef);
            CanvasChart.renderPlayHead(children[i],cache_children[i],this.get_current_frame());
        }
    },
    get_total_frame : function() {
        return Math.round(this.video_element.duration*this.frame_rate);
    },
    get_current_frame : function() {
        return Math.round(this.video_element.currentTime * this.frame_rate);
    },
    set_current_frame : function(new_frame) {
        this.video_element.currentTime =
            (this.video_element.duration*new_frame)/this.get_total_frame();
    },
    reset_au : function() {
        document.forms["action_units"].reset();
        // clean submission message
        var output = document.getElementById('submit_au_success');
        this.clean_output(output);
    },
    setup_event_listeners : function() {
        var that = this;
        that.$video.on('timeupdate', function() {
            // show annotated au
            that.check_au_form();

            // update screen
            that.display_timecode();
            /*
            //var start = new Date().getMilliseconds();
            var end = new Date().getMilliseconds();
            var time = end - start;
            //alert('Execution time: ' + time);
            */
        });

        that.$video.on('durationchange', function() {
            // reinit some info
            that.reinitialise();
            // update screen
            that.display_timecode();
        });

        that.$video.on('loadedmetadata', function() {
            //that.video_element.currentTime = 0.01;
            var $playbar = $('#playbar');
            var $zoombar = $('#zoombar');
            var $playerhead = $('#play_head');
            that.playbar_width = parseInt($playbar.css('width'), 10);
            that.playhead.width = parseInt($playerhead.css('width'), 10);
        });

        that.$video.on('progress', function() {
            that.loading();
        });

        that.$video.on('canplaythrough', function() {
            $('#track_loaded').css('width', '100%');
            $('#track_annotated').css('width', '100%');
            $('#track_selection').css('width', '100%');
            $('#int_segment').css('width', '100%');
        });

    },
    setup_control_handlers : function() {
        var that = this;
        $('#pp').click(function() {
            that.playpause();
            return false;
        });
        $('#rp').click(function() {
            current_frame = that.get_current_frame()
            if (that.playing) {
                that.reset_replay();
                that.video_element.pause();
                that.playing = false;
            } else {
                if (that.frame_interest[current_frame] >= 1) {
                    that.replay_interest();
                    // set timer to stop the replay, check every 15ms, so as not to miss any frame
                    rp_timer = setInterval(function(){
                        // check replay option
                        current_frame = that.get_current_frame();
                        if (current_frame >= that.rp_end || current_frame < that.rp_start) {
                            // handle rare situation
                            if (current_frame == that.rp_end+1) {
                                that.set_current_frame(that.rp_end);
                            }

                            that.reset_replay();
                            that.video_element.pause();
                            that.playing = false;
                        }
                        // clear timer if no need to replay
                        if (!that.rp_interest) {
                            clearInterval(rp_timer);
                        }
                    }, 15);
                }
            }
            return false;
        });
        $('#toPrevInterest').click(function() {
            orig_frame = that.get_current_frame();
            cframe = that.get_current_frame();
            transition = [];

            while (cframe>=0 && transition.length<1) {
                if (that.frame_interest[cframe] >= 1 && cframe != orig_frame
                        && that.frame_interest[cframe-1] == 0) {
                    // count the transition
                    transition.push(cframe);
                } else if (that.frame_interest[cframe] >= 1
                               && cframe == 0) {
                    // if already in the beginning, also count
                    transition.push(cframe);
                }
                cframe -= 1;
            }

            // set new frame
            if (transition.length == 1) {
                new_frame = transition[0]
            } else {
                new_frame = orig_frame;
            }
            that.set_current_frame(new_frame);
            return false;
        });
        $('#toNextInterest').click(function() {
            orig_frame = that.get_current_frame();
            cframe = that.get_current_frame();
            transition = [];

            // go through previous frames
            while (cframe<=that.get_total_frame() && transition.length<1) {
                if (that.frame_interest[cframe] >= 1 && cframe != orig_frame
                        && that.frame_interest[cframe-1] == 0) {
                    // count the transition
                    transition.push(cframe);
                }
                cframe += 1;
            }

            // set new frame
            if (transition.length == 1) {
                new_frame = transition[0]
            } else {
                new_frame = orig_frame;
            }

            that.set_current_frame(new_frame);
            return false;
        });
        $('#stepRw').click(function() {
            that.video_element.currentTime -= 1;
            return false;
        });
        $('#stepFf').click(function() {
            that.video_element.currentTime += 1;
            return false;
        });
        // display all the annotated AUs in the current segment
        $('#display_seg_aus').click(function() {
            var output = $(this);

            var cframe = that.get_current_frame();
            if (that.frame_interest[cframe] == 0) {
                output.jAlert2("Current frame is not in any interest segment!","warning",'warningboxid');
            } else {
                // first find the interest frame range
                var min,max;
                // middle to left
                for (var i1 = cframe; i1 >= 0; --i1) {
                    min = i1;
                    if (that.frame_interest[i1] == 0) { min = i1+1;  break;}
                }
                // middle to right
                for (var i2 = cframe; i2 < that.get_total_frame()+1; ++i2) {
                    max = i2;
                    if (that.frame_interest[i2] == 0) {  max = i2-1;  break;}
                }
                // second go through each au for each interest frame
                var annotated = Array.apply(null, new Array(AU_ORDER.length)).map(function () {return 0;});
                for (var j = 0; j < AU_ORDER.length; ++j) {
                    for (var i = min; i <= max; ++i) {
                        // stop if find the first entry
                        if (that.au[i] != null && that.au[i][2 * j] == true) {
                            annotated[j] = 1;
                            break;
                        }
                    }
                }
                // format the output
                var output_string = "";
                var lines = 0;
                for (var ii = 0; ii < AU_ORDER.length; ++ii) {
                    //if (annotated[ii] == 1) {  output_string += "AU_" + AU_ORDER[ii] + "\n";}
                    //if (annotated[ii] == 1) {  output_string += "AU_" + AU_ORDER[ii] + "<br>";}
                    if (annotated[ii] == 1) {  output_string += AU_NAME[ii] + "<br>";}
                    lines += annotated[ii];
                }

                if (output_string == "") {
                    output.jAlert2("No annotation for this segment!","warning",'warningboxid');
                } else {
                    output.jAlert2("Activated AUs in this segment: <br>"+output_string,"warning",'warningboxid',"",-25*lines/2);
                }

            }
            return false;
        });
        // display all the annotated AUs in the video
        $('#list_all_aus').click(function() {
            var output = $(this);
            // go through each au for each interest frame
            var annotated = Array.apply(null, new Array(AU_ORDER.length)).map(function () {return 0;});
            var n = that.get_total_frame();
            for (var j = 0; j < AU_ORDER.length; ++j) {
                for (var i = 0; i < n+1; ++i) {
                    // stop if find the first entry
                    if (that.au[i] != null && that.au[i][2 * j] == true) {
                        annotated[j] = 1;
                        break;
                    }
                }
            }
            // format the output
            var output_string = "";
            var lines = 0;
            for (var ii = 0; ii < AU_ORDER.length; ++ii) {
                if (annotated[ii] == 1) {  output_string += AU_NAME[ii] + "<br>";}
                lines += annotated[ii];
            }
            if (output_string == "") {
                output.jAlert2("No annotation for this video yet!","warning",'warningboxid');
            } else {
                output.jAlert2("Activated AUs in this video: <br>"+output_string,"warning",'warningboxid',"",-25*lines/2);
            }
            return false;
        });
        $('#pick_interest').click(function() {
            cframe = that.get_current_frame();
            // pick this interesting segment
            if (that.frame_interest[cframe] == 1) {
                // middle to left
                for (var i = cframe; i >= 0; --i) {
                    if (that.frame_interest[i] == 0) {  break;}
                    that.frame_interest[i] = 2;
                }
                // middle to right
                for (var i = cframe; i < that.get_total_frame()+1; ++i) {
                    if (that.frame_interest[i] == 0) {  break;}
                    that.frame_interest[i] = 2;
                }
                that.draw_track_interested();
                that.reset_total_pick();
                that.set_current_pick(cframe);
            }
            return false;
        });
        $('#unpick_interest').click(function() {
            cframe = that.get_current_frame();
            // unpick this interesting segment
            if (that.frame_interest[cframe] == 2) {
                // middle to left
                for (var i = cframe; i >= 0; --i) {
                    if (that.frame_interest[i] == 0) {  break;}
                    that.frame_interest[i] = 1;
                }
                // middle to right
                for (var i = cframe; i < that.get_total_frame()+1; ++i) {
                    if (that.frame_interest[i] == 0) {  break;}
                    that.frame_interest[i] = 1;
                }
                that.draw_track_interested();
                that.reset_total_pick();
                that.set_current_pick(cframe);
            }
            return false;
        });

        // Player bar
        $('#play_head').mousedown(function() {
            that.playHeadDrag();
            return false;
        });

        // Control Bar
        $('#track_loaded').click(function(e) {
            that.position_to_time(e);
        });

        $('#track_annotated').click(function(e) {
            that.position_to_time(e);
        });

        $('#track_selection').click(function(e) {
            that.position_to_time(e);
        });

        $('#int_segment').click(function(e) {
            that.position_to_time(e);
        });

        $('#goto_frame').keydown(function(e) {
            if (e.keyCode === 13) {
                that.set_current_frame(this.value);
                return false;
            }
        }).keyup(function() {
            return false;
        });

        $('#zoom_goto_frame').keydown(function(e) {
            if (e.keyCode === 13) {
                if (that.zoom_mode == true) {
                    var value = parseInt(this.value);
                    var bar = document.getElementById('zoom_frame');
                    if (value > bar.max) {
                        value = bar.max;
                    } else if (value < bar.min) {
                        value = bar.min;
                    }
                    that.set_current_frame(value);
                }
                return false;
            }
        }).keyup(function() {
            return false;
        });

        // reset action unit form
        $('#reset_au').click( function() {
            that.reset_au();
            return false;
        });
        // submit action unit form
        $('#submit_au').click( function() {
            that.submit_current_form();
            return false;
        });
        // clear current action unit form
        $('#clear_au').click( function() {
            that.clear_current_form();
            return false;
        });
        // create link for annotation download
        $('#save_anno').click( function() {
            var output = document.getElementById('link_anno');
            var blob_data = that.convert_au_to_blob();
            var download_name = document.getElementById('download_anno_name').value;
            that.downloadFile(blob_data,output,download_name);
            return false;
        });
        // create link for interesting frame download
        $('#save_interest').click( function() {
            // sanity check, to avoid picking interest segments with same length
            var n = that.get_total_frame();
            picked_interest = [];
            // the last frame is replicate of previous ones, shouldn't be counted
            count = 0;
            flag = false;
            for (var i = 0; i < n; ++i) {
                if (that.frame_interest[i] != 2 && that.frame_interest[i+1] == 2) {
                    flag = true;
                    count = 0;
                } else if (that.frame_interest[i] == 2 && that.frame_interest[i+1] != 2) {
                    flag = false;
                    picked_interest.push(count);
                    count = 0;
                }
                if (flag) { count++;}
            }
            // find duplicate elements
            var sorted_pi = picked_interest.sort();
            var results = [];
            for (var i = 0; i < sorted_pi.length - 1; i++) {
                if (sorted_pi[i + 1] == sorted_pi[i]) {
                    results.push(sorted_pi[i]);
                }
            }

            if (results.length == 0) {
                var output = document.getElementById('link_interest');
                var blob_data = that.convert_int_to_blob();
                var download_name = document.getElementById('download_interest_name').value;
                that.downloadFile(blob_data,output,download_name);
            } else {
                alert("Cannot save, mind the length(s): " + results);
            }
            return false;
        });
        // declare interested segments
        $('#declare_interest').click( function() {
            if (that.flag_A && that.flag_B) {
                for (var i = Math.min(that.frame_A,that.frame_B); i<=Math.max(that.frame_A,that.frame_B); ++i) {
                    that.frame_interest[i] = 1;
                }
                that.draw_track_interested();
                that.reset_AB();
                // reset zoom interest
                that.reset_zoom_info();
            }
            return false;
        });
        // clear interested segments
        $('#clear_interest').click( function() {
            if (that.flag_A && that.flag_B) {
                for (var i = Math.min(that.frame_A,that.frame_B); i<=Math.max(that.frame_A,that.frame_B); ++i) {
                    that.frame_interest[i] = 0;
                }
                that.draw_track_interested();
                that.reset_AB();
                // reset zoom interest
                that.reset_zoom_info();
                // reset pick info
                that.reset_total_pick();
                that.set_current_pick(that.get_current_frame());
            }
            return false;
        });
        // break one interested segment
        $('#break_interest').click( function() {
            // check if we are currently in an interesting segment
            current_frame = that.get_current_frame()
            if (that.frame_interest[current_frame] >= 1) {
                that.frame_interest[current_frame] = 0
                that.draw_track_interested();
                // reset zoom interest
                that.reset_zoom_info();
                // reset pick info
                that.reset_total_pick();
                that.set_current_pick(current_frame);
            }
            return false;
        });
        // clear the left interested segments
        $('#clear_left_interest').click( function() {
            // check if we are currently in an interesting segment
            current_frame = that.get_current_frame()
            if (that.frame_interest[current_frame] >= 1) {
                // wipe left part
                left = current_frame-1
                while (that.frame_interest[left] >= 1 && left >= 0) {
                    that.frame_interest[left--] = 0
                }
                that.draw_track_interested();
                // reset zoom interest
                that.reset_zoom_info();
                // reset pick info
                that.reset_total_pick();
                that.set_current_pick(current_frame);
            }
            return false;
        });
        // clear the right interested segments
        $('#clear_right_interest').click( function() {
            // check if we are currently in an interesting segment
            current_frame = that.get_current_frame()
            if (that.frame_interest[current_frame] >= 1) {
                right = current_frame+1
                while (that.frame_interest[right] >= 1 && right <= that.get_total_frame()) {
                    that.frame_interest[right++] = 0
                }

                that.draw_track_interested();
                // reset zoom interest
                that.reset_zoom_info();
                // reset pick info
                that.reset_total_pick();
                that.set_current_pick(current_frame);
            }
            return false;
        });
        // clear the whole interested segments
        $('#clear_whole_interest').click( function() {
            // check if we are currently in an interesting segment
            current_frame = that.get_current_frame()
            if (that.frame_interest[current_frame] >= 1) {
                // wipe left part
                left = current_frame
                while (that.frame_interest[left] >= 1 && left >= 0) {
                    that.frame_interest[left--] = 0
                }

                right = current_frame+1
                while (that.frame_interest[right] >= 1 && right <= that.get_total_frame()) {
                    that.frame_interest[right++] = 0
                }

                that.draw_track_interested();
                // reset zoom interest
                that.reset_zoom_info();
                // reset pick info
                that.reset_total_pick();
                that.set_current_pick(current_frame);
            }
            return false;
        });
        // apply au annotations upon current annotation for this segment
        $('#apply_segment_au').click( function() {
            if (that.flag_A && that.flag_B) {
                // for every frame within segment
                for (var i = Math.min(that.frame_A,that.frame_B); i<=Math.max(that.frame_A,that.frame_B); ++i) {
                    // If no current anno, then create a new one;
                    // Otherwise, overwrite current annotation only for the activated AU
                    if (that.au[i] == null) {
                        that.au[i] = new Array(AU_ORDER.length*2);
                        for (var k = 0; k < AU_ORDER.length; ++k) {
                            that.au[i][2*k] = document.forms["action_units"]["au"+AU_ORDER[k]].checked;
                            that.au[i][2*k+1] = document.forms["action_units"]["i"+AU_ORDER[k]].value;
                        }
                    } else {
                        for (var k = 0; k < AU_ORDER.length; ++k) {
                            var tmp = document.forms["action_units"]["au"+AU_ORDER[k]].checked;
                            if (tmp == true) {
                                that.au[i][2*k] = tmp;
                                that.au[i][2*k+1] = document.forms["action_units"]["i"+AU_ORDER[k]].value;
                            }
                        }
                    }
                }
                that.draw_track_annotated();
                that.draw_track_selection();
                that.update_aus_canvas();
                that.reset_AB();
            }
            return false;
        });
        // wipe selected AU on current annotation for this segment
        $('#wipe_segment_part').click( function() {
            if (that.flag_A && that.flag_B) {
                // for every frame within segment
                for (var i = Math.min(that.frame_A,that.frame_B); i<=Math.max(that.frame_A,that.frame_B); ++i) {
                    // wipe current annotation only for the activated AU
                    if (that.au[i] != null) {
                        var true_count = 0;
                        for (var k = 0; k < AU_ORDER.length; ++k) {
                            var tmp = document.forms["action_units"]["au"+AU_ORDER[k]].checked;
                            // if need to wipe out
                            if (tmp == true) {
                                that.au[i][2*k] = false;
                                that.au[i][2*k+1] = 1;
                            }
                            // count if no false
                            if (that.au[i][2*k] == true) {
                                true_count += 1;
                            }
                        }
                        if (true_count == 0) {
                            that.au[i] = null;
                        }
                    }
                }
                that.draw_track_annotated();
                that.draw_track_selection();
                that.reset_AB();
            }
            return false;
        });
        // clear all the au annotations in this segment
        $('#clear_segment_au').click( function() {
            if (that.flag_A && that.flag_B) {
                for (var i = Math.min(that.frame_A,that.frame_B); i<=Math.max(that.frame_A,that.frame_B); ++i) {
                    that.au[i] = null;
                }
                that.draw_track_annotated();
                that.draw_track_selection();
                that.update_aus_canvas();
                that.reset_au();
                that.reset_AB();
            }
            return false;
        });
        // A in AB selection
        $('#start_A').click( function() {
            that.flag_A ^= true;
            if (that.flag_A == true) {
                that.frame_A = that.get_current_frame();
                $('#out_frame_A').text(that.frame_A);
                document.getElementById('start_A').setAttribute('border','4');
                // if A and B are both selected, reset form for annotation
                if (that.flag_B == true) {
                    that.reset_au();
                }
            } else {
                that.frame_A = -1;
                $('#out_frame_A').text(that.frame_A);
                document.getElementById('start_A').setAttribute('border','0');
            }
            return false;
        });
        // B in AB selection
        $('#end_B').click( function() {
            that.flag_B ^= true;
            if (that.flag_B == true) {
                that.frame_B = that.get_current_frame();
                $('#out_frame_B').text(that.frame_B);
                document.getElementById('end_B').setAttribute('border','4');
                // if A and B are both selected, reset form for annotation
                if (that.flag_A == true) {
                    that.reset_au();
                }
            } else {
                that.frame_B = -1;
                $('#out_frame_B').text(that.frame_B);
                document.getElementById('end_B').setAttribute('border','0');
            }
            return false;
        });
        // click to show the upper au list or not
        $('#show_ufa').click( function() {
            var table = document.getElementById('upperFAU_display');
            var value;
            if (this.getAttribute("value") == "false") {
                $(table).show().addClass("active");
                this.innerHTML = "[ - ]";
                value = "true";
            } else if (this.getAttribute("value") == "true") {
                $(table).hide().removeClass("active");
                this.innerHTML = "[ + ]";
                value = "false";
            }
            this.setAttribute("value",value);
        });
        // click to show the lower au list or not
        $('#show_lfa').click( function() {
            var table = document.getElementById('lowerFAU_display');
            var value;
            if (this.getAttribute("value") == "false") {
                $(table).show().addClass("active");
                this.innerHTML = "[ - ]";
                value = "true";
            } else if (this.getAttribute("value") == "true") {
                $(table).hide().removeClass("active");
                this.innerHTML = "[ + ]";
                value = "false";
            }
            this.setAttribute("value",value);
        });
        // aus display listener - add canvas
        $("#aus_display").on("select2-selecting", function(e) {
            var output = document.getElementById('aus_canvas');
            var cache_output = document.getElementById('cache_aus_canvas');

            var canv = document.createElement("canvas");
            canv.setAttribute('width', output.offsetWidth);
            canv.setAttribute('height', 70);
            canv.setAttribute('id', 'au_canv_'+e.val);

            var cache_canv = document.createElement("canvas");
            cache_canv.setAttribute('width', canv.width);
            cache_canv.setAttribute('height', canv.height);
            cache_canv.setAttribute('id', 'cache_au_canv_'+e.val);

            var dataDef = that.set_aus_display_data(e.val);

            // render the figure
            // first draw the cache image, and make a copy of drawing from cache
            //CanvasChart.render(canv, dataDef);
            CanvasChart.render(canv, cache_canv, dataDef);
            CanvasChart.renderPlayHead(canv, cache_canv, that.get_current_frame());

            output.appendChild(canv);
            cache_output.appendChild(cache_canv);
        });
        // aus display listener - remove canvas
        $("#aus_display").on("select2-removing", function(e) {
            var output = document.getElementById('aus_canvas');
            var cache_output = document.getElementById('cache_aus_canvas');
            var children = output.childNodes;
            var cache_children = cache_output.childNodes;
            // remove canvas if found one
            for (var i = 0; i < children.length; ++i) {
                if (children[i].id == 'au_canv_'+e.val) {
                    output.removeChild(children[i]);
                    cache_output.removeChild(cache_children[i]);
                    break;
                }
            }
        });
    },
    // setup AU example display handler
    setup_au_example_display_handler : function() {
        var display_handles = document.getElementsByClassName("display_au_example");

        var au_example_display = function(e) {
            e.preventDefault();
            au_order = this.getAttribute("au_order");
            au_idx = null;
            for (var i = 0; i < AU_ORDER.length; ++i) {
                if (AU_ORDER[i] === au_order) {
                    au_idx = i;
                    break;
                }
            }
            src_example = ["src='au_examples/", AU_EXAMPLE[au_idx], "'"].join("");
            contents = ["<b>An example of this AU: </b><br>",
                        "<div class='vidWrap'><image style='width:100%; height: 100%' ",
                        src_example, " frameborder='0' allowfullscreen></image></div>"];
            $.jAlert({
                'title': AU_NAME[au_idx],
                'content': contents.join(""),
                'theme': "gray",
            });
        };

        for (var i = 0; i < display_handles.length; i++) {
            display_handles[i].addEventListener('click', au_example_display, false);
        }
    },
    // submit form
    submit_current_form : function() {
        console.log("current frame: " + this.get_current_frame());

        var i = this.get_current_frame();
        if (this.au[i] == null) {
            this.au[i] = new Array(AU_ORDER.length*2);
        }

        for (var k = 0; k < AU_ORDER.length; ++k) {
            this.au[i][2*k] = document.forms["action_units"]["au"+AU_ORDER[k]].checked;
            this.au[i][2*k+1] = document.forms["action_units"]["i"+AU_ORDER[k]].value;
        }

        // display succeed info
        var output = document.getElementById('submit_au_success');
        output.value = "Submission Completed!";

        // update bar
        this.draw_track_annotated();
        this.draw_track_selection();
        this.update_aus_canvas();

        // jump to next frame
        //this.jump_frames(1);
    },
    // clear form
    clear_current_form : function() {
        console.log("current frame: " + this.get_current_frame());

        var i = this.get_current_frame();
        this.au[i] = null;

        // reset form
        this.reset_au();

        // display succeed info
        var output = document.getElementById('submit_au_success');
        output.value = "Clearance Completed!";

        // update bar
        this.draw_track_annotated();
        this.draw_track_selection();
        this.update_aus_canvas();

        // jump to next frame
        //this.jump_frames(1);
    },
    // check annotated frame and set the annotated form if have
    check_au_form : function() {
        var i = this.get_current_frame();
        if (this.au[i] != null) {
            //console.log(this.au[i]);

            for (var k = 0; k < AU_ORDER.length; ++k) {
                document.forms["action_units"]["au"+AU_ORDER[k]].checked = this.au[i][2*k];
                document.forms["action_units"]["i"+AU_ORDER[k]].value = this.au[i][2*k+1];
            }
        } else {
            document.forms["action_units"].reset();
        }
    },

    // convert current annotation to blob object
    convert_au_to_blob : function() {
        var n = this.get_total_frame();
        var annotations = new Array(n);

        for (var i = 0; i < n; ++i) {
            var tmp = [];
            if (this.au[i] == null) {  tmp.push(i+": N/A\n");}
            else {  tmp.push(i+": "+ this.au[i] + "\n");}
            annotations[i] = tmp;
        }

        return new Blob(annotations, {type: MIME_TYPE});
    },

    // convert current interest frame index to blob object
    convert_int_to_blob : function() {
        var n = this.get_total_frame();
        var blob_data = [];

        for (var i = 0; i < n; ++i) {
            blob_data.push(this.frame_interest[i] + " ");
        }
        return new Blob(blob_data, {type: MIME_TYPE});
    },

    // clean up output
    clean_output : function(output) {
        if (output.value != null) {
            output.value = "";
        }
    },

    // clean up the link
    clean_link : function(output) {
        var prevLink = output.getElementsByTagName('a');
        if (prevLink) {
            window.URL.revokeObjectURL(prevLink.href);
            output.innerHTML = '';
        }
    },

    // create link for download
    downloadFile : function(blob_data,output,download_name) {
        window.URL = window.webkitURL || window.URL;

        //var output = document.getElementById('link_anno');
        this.clean_link(output);

        //var bb = this.convert_au_to_blob();

        var a = document.createElement('a');
        //a.download = document.getElementById('download_anno_name').value;
        a.download = download_name;
        a.href = window.URL.createObjectURL(blob_data);
        a.textContent = 'Download ready';

        a.dataset.downloadurl = [MIME_TYPE, a.download, a.href].join(':');
        a.draggable = false; // Don't really need, but good practice.

        output.appendChild(a);

        a.onclick = function(e) {
            if ('disabled' in this.dataset) {
              return false;
            }

            // mark link as disabled
            this.textContent = 'Downloaded';
            this.dataset.disabled = true;

            // Need a small delay for the revokeObjectURL to work properly.
            setTimeout(function() {  window.URL.revokeObjectURL(this.href);}, 1500);
        };
    },

    // load annotation file
    load_annotation : function(fileList) {
        if (fileList.length > 0) {
            var file = fileList[0];
            var split_name = file.name.split('.');
            split_name = split_name.pop();
            if (split_name.toLowerCase() === 'txt') {
                var reader = new FileReader();
                reader.readAsText(file);
                reader.that = this;
                // asynchronous action, would be executed after loading ends
                reader.onload = function(e) {
                    // e.target.result should contain the text
                    var content = e.target.result.split("\n");
                    if (content[content.length-1] === "") {
                        content.pop();
                    }
                    this.that.set_au(content);
                };
            }
        }
    },

    // set interest segment according to AU annotation
    set_int_from_au : function(au_array) {
        var n = this.get_total_frame();
        for (var i = 0; i < n; ++i) {
            if (au_array[i] != null) {
                this.frame_interest[i] = 1;
            }
        }
    },

    // set au annotation info, set the interest segment wherever AU is activated
    set_au : function(content) {
        var n = this.get_total_frame();
        if (content.length != n) {
            window.alert('Loaded annotation file does not match current video!');
        } else {
            // set the annotations
            for (var i = 0; i < n; ++i) {
                // reset all aus
                this.au[i] = null;
                // if no content, then skip
                var tmp = content[i].split(' ');
                if (tmp[1] === 'N/A') {
                    continue;
                }
                // if have contents
                this.au[i] = new Array(AU_ORDER.length*2);
                var tmp_aus = tmp[1].split(',');
                for (var j = 0; j < tmp_aus.length/2; ++j) {
                    this.au[i][2*j] = (tmp_aus[2*j] === 'true');
                    this.au[i][2*j+1] = tmp_aus[2*j+1];
                }
            }
            // reset set the last frame
            this.au[n] = null;
        }
        // update interesting frame
        this.set_int_from_au(this.au);
        this.draw_track_interested();
        // update bar
        this.draw_track_annotated();
        this.draw_track_selection();
        this.update_aus_canvas();
    },

    // load interest frame file
    load_interest : function(fileList) {
        if (fileList.length > 0) {
            var file = fileList[0];
            var split_name = file.name.split('.');
            split_name = split_name.pop();
            if (split_name.toLowerCase() === 'txt') {
                var reader = new FileReader();
                reader.readAsText(file);
                reader.that = this;
                // asynchronous action, would be executed after loading ends
                reader.onload = function(e) {
                    // e.target.result should contain the text
                    var content = e.target.result.split(" ");
                    if (content[content.length-1] === "") {
                        content.pop();
                    }
                    this.that.set_int(content);
                };
            }
        }
    },

    // set interest frame info
    set_int : function(content) {
        var n = this.get_total_frame();
        if (content.length != n) {
            window.alert('Loaded annotation file does not match current video!');
        } else {
            // set the annotations
            for (var i = 0; i < n; ++i) {
                this.frame_interest[i] = content[i];
            }
        }
        // update bar
        this.draw_track_interested();
        // reset zoom interest
        this.reset_zoom_info();
        // reset pick info
        this.reset_total_pick();
        this.set_current_pick(0);
    },

    // reset AB repeat
    reset_AB : function() {
        this.flag_A = false;
        this.flag_B = false;
        document.getElementById('start_A').setAttribute('border','0');
        document.getElementById('end_B').setAttribute('border','0');
    },

    // reset AUS display
    reset_aus_display : function() {
        $("#aus_display").select2("val", "");
        var output = document.getElementById('aus_canvas');
        while (output.firstChild) {
            output.removeChild(output.firstChild);
        }
        var cache_output = document.getElementById('cache_aus_canvas');
        while (cache_output.firstChild) {
            cache_output.removeChild(cache_output.firstChild);
        }
    },

    // set which AU bar to be displayed
    set_display_option : function(idx) {
        this.display_bar = idx;
        this.draw_track_selection();
    },

    // format the au info to display figure
    set_aus_display_data : function(idx) {
        var dataDef = { title: "AU "+AU_ORDER[idx],
                        //xLabel: 'Year',
                        //yLabel: 'Population (millions)',
                        labelFont: '12pt Arial',
                        dataPointFont: '10pt Arial',
                        renderTypes: [CanvasChart.renderType.lines],
                        dataPoints: new Array(this.get_total_frame()+1)
                       };
        // set AU data
        for (var i = 0; i < this.get_total_frame()+1; ++i) {
            if (this.au[i] != null && this.au[i][2*idx] == true) {
                dataDef.dataPoints[i] = {x: i.toString(), y:this.au[i][2*idx+1]};
            } else {
                dataDef.dataPoints[i] = {x: i.toString(), y:0};
            }
        }
        return dataDef;
    },

    // set zooming interest mode
    set_zoom_option : function(checked) {
        this.zoom_mode = checked;
        if (checked == true) {
            var cframe = this.get_current_frame();
            this.set_zoom_info(cframe);
        } else if (checked == false) {
            this.reset_zoom_info();
        }
        this.display_timecode();
    },

    // set zoom parameter
    set_zoom_info : function(cframe) {
        var bar = document.getElementById('zoom_frame');
        // if nothing interest here
        if (this.frame_interest[cframe] == 0) {
            return;
        }
        // middle to left
        for (var i = cframe; i >= 0; --i) {
            bar.min = i;
            if (this.frame_interest[i] == 0) {
                bar.min = i+1;
                break;
            }
        }
        // middle to right
        for (var i = cframe; i < this.get_total_frame()+1; ++i) {
            bar.max = i;
            if (this.frame_interest[i] == 0) {
                bar.max = i-1;
                break;
            }
        }
    },

    // reset zoom parameter
    reset_zoom_info : function() {
        var bar = document.getElementById('zoom_frame');
        bar.min = -1;
        bar.max = -1;
        // reset info
        document.getElementById('zoom_goto_frame').value = -1;
        document.getElementById('zoom_frame').value = -1;
        $('#int_start').text(bar.min);
        $('#int_end').text(bar.max);
    },

    // move to frame in zoom mode
    move_frame_zoom : function(value) {
        if (this.zoom_mode == true) {
            this.set_current_frame(value);
            this.display_timecode();
        }
    },

    // reset picked information
    reset_total_pick : function() {
        total = 0;
        total_segment = 0;
        var n = this.get_total_frame();
        // the last frame is replicate of previous ones, shouldn't be counted
        for (var i = 0; i < n+1; ++i) {
            if (this.frame_interest[i] == 2) {  total += 1;}

            if (this.frame_interest[i] == 2 && this.frame_interest[i+1] != 2) {  total_segment += 1;}
        }
        $('#total_segment').text(total_segment);
        $('#total_picked').text(total);
    },

    set_current_pick : function(cframe) {
        current_len = 0;
        this.pick_left = cframe;
        this.pick_right = cframe;
        if (this.frame_interest[cframe] == 2) {
            // middle to left
            for (var i = cframe; i >= 0; --i) {
                if (this.frame_interest[i] != 2) { break;}
                this.pick_left = i;
                current_len += 1;
            }
            // middle to right
            for (var i = cframe+1; i < this.get_total_frame()+1; ++i) {
                if (this.frame_interest[i] != 2) { break;}
                this.pick_right = i
                current_len += 1;
            }
        }
        $('#current_picked').text(current_len);
    },

    initialise : function(video_element_id) {
        this.$video = $(video_element_id);
        this.video_element = this.$video.get(0);
        this.src_url = this.$video.attr('src');
        this.frame_rate = this.$video.attr('data-framerate');
        this.video_name = this.$video.attr('video_name');
        this.playhead = {'mouse_down' : false};
        // info for AB repeat
        this.flag_A = false;
        this.flag_B = false;
        this.frame_A = -1;
        this.frame_B = -1;
        // display bar option
        this.display_bar = -1;

        // zoom interest option
        this.zoom_mode = true;
        document.getElementById("zoom_mode").checked = true;

        // replay interest option
        this.reset_replay()

        // call the plugin
        $("#aus_display").select2({ maximumSelectionSize: 9 });

        // call the tab plugin
        $(".tabs a").html5jTabs();

        this.setup_event_listeners();
        this.setup_control_handlers();

        // setup AU example display listener
        this.setup_au_example_display_handler();

        return this;
    },

    reinitialise : function() {
        var s = document.getElementById("subject_video");
        this.video_name = s.getAttribute('video_name');
        var name = this.video_name.split(".");
        document.getElementById('download_anno_name').value = 'AU_' + name[0] + '.txt';
        document.getElementById('download_interest_name').value = 'Int_' + name[0] + '.txt';

        // reset AB repeat flag
        this.flag_A = false;
        this.flag_B = false;
        this.frame_A = -1;
        this.frame_B = -1;

        // display bar option
        this.display_bar = -1;

        // create interest frame
        this.frame_interest = Array.apply(null, new Array(this.get_total_frame()+1)).map(function () {return 0;});
        this.draw_track_interested();

        // create new array list for au annotation
        this.au = new Array(this.get_total_frame()+1);
        // reset au
        this.reset_au();

        // reset zoom info
        this.zoom_mode = true;
        document.getElementById("zoom_mode").checked = true;
        this.reset_zoom_info();

        // reset pick info
        this.reset_total_pick();
        this.set_current_pick(0);

        // reset replay interest option
        this.reset_replay()

        // reset download link
        this.clean_link(document.getElementById('link_anno'));

        // reset AUs display selection form
        this.reset_aus_display();

        this.draw_track_annotated();
        this.draw_track_selection();
    }
};

$(document).ready(function() {

    var video_control = SegmentVideo.initialise('#subject_video');

    $('label').disableSelection();

    $(document).keydown(function(e) {
        // Space Bar
        if (e.keyCode == 32) {
            video_control.playpause();
            //video_control.submit_current_form();
        }
        // Arrow Keys
        // 'left' or 'a'
        //if (e.keyCode == 37 || e.keyCode == 65) {
        if (e.keyCode == 37) {
            video_control.jump_frames(-1);
        }
        // 'right' or 'd'
        //if (e.keyCode == 39 || e.keyCode == 68) {
        if (e.keyCode == 39) {
            video_control.jump_frames(1);
        }
        if (e.keyCode == 38) {
            //video_control.jump_frames(60);
        }
        if (e.keyCode == 40) {
            //video_control.jump_frames(-60);
        }
    });

    $(document).mouseup(function() {
        if (video_control.playhead.mouse_down) {
            video_control.playhead.mouse_down = false;
            if (video_control.startAgain) {
                video_control.startAgain = false;
                video_control.playMovie();
            }
        }
    });

    $(document).mousemove(function(e) {
        if (video_control.playhead.mouse_down) {
            video_control.position_to_time(e);
        }
    });

});

// Csy functions
//document.getElementById("input").addEventListener("change", load_new_video, false);


//

document.addEventListener('DOMContentLoaded', function() {
    var inputElement = document.getElementById("input");
    inputElement.addEventListener("onclick", load_new_video, false);
});

function load_new_video(fileList) {
    if (fileList.length > 0) {
        var file = fileList[0];
        var obj_url = window.URL.createObjectURL(file);
        document.getElementById("subject_video").setAttribute("src",obj_url);
        document.getElementById("subject_video").setAttribute("video_name",file.name);
    }
}

// JQuery function for tab display
;(function($){
  // enable tab function
  $.fn.html5jTabs = function(options){
    return this.each(function(index, value){
      var obj = $(this),
      objFirst = obj.eq(index),
      objNotFirst = obj.not(objFirst);

      $("#" +  objNotFirst.attr("data-toggle")).hide();
      $(this).eq(index).addClass("active");

      obj.click(function(evt){

        var toggler = "#" + obj.attr("data-toggle");
        // find all the divs
        var togglerAll = $(toggler).parent().find("div");
        // find all the divs belongs to activated div
        var toggler_subdiv = $(toggler).find("div");

        togglerAll.hide().removeClass("active");
        $(toggler).show().addClass("active");
        $(toggler_subdiv).show().addClass("active");

        //toggle Active Class on tab buttons
        $(this).parent("div").find("a").removeClass("active");
        $(this).addClass("active");

        return false; //Stop event Bubbling and PreventDefault
      });
    });
  };

  // enable text unselection
  $.fn.extend({
    disableSelection: function() {
        this.each(function() {
            if (typeof this.onselectstart != 'undefined') {
                this.onselectstart = function() { return false; };
            } else if (typeof this.style.MozUserSelect != 'undefined') {
                this.style.MozUserSelect = 'none';
            } else {
                this.onmousedown = function() { return false; };
            }
        });
    }
  });
}(jQuery));
