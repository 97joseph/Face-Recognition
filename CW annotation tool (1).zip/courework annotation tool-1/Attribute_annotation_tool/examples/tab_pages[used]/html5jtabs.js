;(function($){
  $.fn.html5jTabs = function(options){
    return this.each(function(index, value){
      var obj = $(this),
      objFirst = obj.eq(index),
      objNotFirst = obj.not(objFirst);

      $("#" +  objNotFirst.attr("data-toggle")).hide();
      $(this).eq(index).addClass("active");

      obj.click(function(evt){

        var toggler = "#" + obj.attr("data-toggle");
        // find all the divs
        var togglerAll = $(toggler).parent().find("div");
        // find all the divs belongs to activated div
        var toggler_subdiv = $(toggler).find("div");

        togglerAll.hide().removeClass("active");
        $(toggler).show().addClass("active");
        $(toggler_subdiv).show().addClass("active");

        //toggle Active Class on tab buttons
        $(this).parent("div").find("a").removeClass("active");
        $(this).addClass("active");

        return false; //Stop event Bubbling and PreventDefault
      });
    });
  };
}(jQuery));