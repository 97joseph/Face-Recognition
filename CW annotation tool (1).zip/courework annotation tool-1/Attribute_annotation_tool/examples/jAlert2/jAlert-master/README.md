jAlert
======

Demo & Documentation:
http://flwebsites.biz/jAlert/
